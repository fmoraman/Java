package com.example.fmora.ggaction;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Parcelable;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

public class MainActivity extends AppCompatActivity {
     private EditText Id, name, model, brand;
    private Button details;
    private Spinner spinner;
    private String carr;
    private Control control;
    private List<Data> carros = new ArrayList<Data>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        control=new Control();

        Id = (EditText) findViewById(R.id.id);
        name = (EditText) findViewById(R.id.nombre);
        model = (EditText) findViewById(R.id.modelo);
        brand = (EditText) findViewById(R.id.marca);
        details = (Button) findViewById(R.id.detalles);
        spinner = (Spinner) findViewById(R.id.spinner);


        final String[] car = new String[]{"Seleccione", "Corvette", "Audi", "Mini Cooper"};
        final ArrayAdapter<String> adaptador = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, car);
        spinner.setAdapter(adaptador);

        Data carro = new Data(755, "ZR1", "Corvette", "2019");
        //carros.add(carro);
        control.setData(carro);
        Data carro1 = new Data(540, "R8 Spyder", "Audi", "2019");
        //carros.add(carro1);
        control.setData(carro1);
        Data carro2 = new Data(235, "Mini Cooper S 3 door", "Mini Cooper", "2019");
        //carros.add(carro2);
        control.setData(carro2);


        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            @SuppressLint("SetTextI18n")
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                carr = car[position];
                if(carr == "Corvette"){
                    Id.setText("755");
                    name.setText("ZR1");
                    model.setText("2019");
                    brand.setText("Corvette");
                }
                if(carr == "Audi"){
                    Id.setText("540");
                    name.setText("R8 Spyder");
                    model.setText("2019");
                    brand.setText("Audi");
                }
                if(carr == "Mini Cooper"){
                    Id.setText("235");
                    name.setText("Mini Cooper S 3 door");
                    model.setText("2019");
                    brand.setText("Mini Cooper");
                }

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        details.setOnClickListener(new View.OnClickListener() {
            @Override
            @SuppressLint("SetTextI18n")
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Second.class);
                if (carr == "Corvette") {
                    intent.putExtra("id", "755");
                    intent.putExtra("name", "ZR1");
                    intent.putExtra("model", "2019");
                    intent.putExtra("brand", "Corvette");
                    intent.putExtra("numc", "8 en V");
                    intent.putExtra("price", "$2,784,900");
                }
                if (carr == "Audi") {
                    intent.putExtra("id", "540");
                    intent.putExtra("name", "R8 Spyder");
                    intent.putExtra("model", "2019");
                    intent.putExtra("brand", "Audi");
                    intent.putExtra("numc", "10 en V");
                    intent.putExtra("price", "$3,179,900");
                }
                if (carr == "Mini Cooper") {
                    intent.putExtra("id", "235");
                    intent.putExtra("name", "Mini Cooper S 3 door");
                    intent.putExtra("model", "2019");
                    intent.putExtra("brand", "Mini Cooper");
                    intent.putExtra("numc", "4");
                    intent.putExtra("price", "$554,900");
                }
                startActivity(intent);
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.action, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        final String[] car = new String[]{"Seleccione", "Corvette", "Audi", "Mini Cooper"};
        final ArrayAdapter<String> adaptador = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, car);
        spinner.setAdapter(adaptador);

        switch (item.getItemId()) {
            case R.id.nuevo:

                Data newcar = new Data(Integer.parseInt(Id.getText().toString()), name.getText().toString(), brand.getText().toString(), model.getText().toString());
                control.setData(newcar);
                //carros.add(newcar);
                //adaptador.notifyDataSetChanged();

                Id.setText("");
                name.setText("");
                model.setText("");
                brand.setText("");
                return true;
            case R.id.buscar:
                //for (Data data : carros) {
                //Data data = new Data();
                int id = Integer.parseInt(Id.getEditableText().toString());
                Data d = new Data();
                d.setId(id);
                final Data data = control.consultar(d);

                    if (data.getId() > 0) {
                        name.setText(data.getName());
                        model.setText(data.getModel());
                        brand.setText(data.getBrand());
                    }

                return true;


            case R.id.modificar:
                int idd = Integer.parseInt(Id.getEditableText().toString());
                Data dd = new Data();
                dd.setId(idd);
                final Data dataa = control.consultar(dd);
                if (dataa.getId() > 0) {
                    name.setText(dataa.getName());
                    model.setText(dataa.getModel());
                    brand.setText(dataa.getBrand());
                }
                Data modcar = new Data(Integer.parseInt(Id.getText().toString()), name.getText().toString(), brand.getText().toString(), model.getText().toString());
                control.setData(modcar);
                Id.setText("");
                name.setText("");
                model.setText("");
                brand.setText("");
            case R.id.eliminar:
                AlertDialog.Builder dialogo1 = new AlertDialog.Builder(MainActivity.this);
                dialogo1.setTitle("Importante");
                dialogo1.setMessage("¿ Seguro que quieres borrar el auto ?");
                AlertDialog.Builder confirmar = dialogo1.setPositiveButton("Confirmar", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialogo1, int id) {
                       Id.setText("");
                        name.setText("");
                        model.setText("");
                        brand.setText("");

                    }
                });
                dialogo1.show();
            default:
                return super.onOptionsItemSelected(item);
        }

    }
}
