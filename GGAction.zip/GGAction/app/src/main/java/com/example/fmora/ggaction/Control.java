package com.example.fmora.ggaction;

public class Control {

        private Data datos[];
        private int DataAcc;

        public Control(){
            datos= new Data[10];
            DataAcc=0;
        }

        public void setData(Data d){
            if(DataAcc<10)
            {
                datos[DataAcc] = d;
                DataAcc++;
            }
        }
        public Data consultar (Data d){
            Data obj = new Data();
            for(int x = 0; x < DataAcc; x++){
                if(datos[x].getId()==d.getId()){
                    obj=datos[x];
                    break;
                }
            }
            return obj;
        }
    }



