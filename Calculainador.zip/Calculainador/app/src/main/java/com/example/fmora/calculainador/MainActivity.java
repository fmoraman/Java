package com.example.fmora.calculainador;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {

    Button bt1, bt2, bt3, bt4, bt5, bt6, bt7, bt8, bt9, bt0, btadd, btsub, btmul, btdiv, btres, btdot, btclean;
    TextView blank;
    Float numb1, numb2;
    Boolean add = false, sub = false , mul = false , div = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bt1=(Button)findViewById(R.id.uno);
        bt2=(Button)findViewById(R.id.dos);
        bt3=(Button)findViewById(R.id.tres);
        bt4=(Button)findViewById(R.id.cuatro);
        bt5=(Button)findViewById(R.id.cinco);
        bt6=(Button)findViewById(R.id.seis);
        bt7=(Button)findViewById(R.id.siete);
        bt8=(Button)findViewById(R.id.ocho);
        bt9=(Button)findViewById(R.id.nueve);
        bt0=(Button)findViewById(R.id.cero);
        btadd=(Button)findViewById(R.id.suma);
        btsub=(Button)findViewById(R.id.resta);
        btmul=(Button)findViewById(R.id.multiplicacion);
        btdiv=(Button)findViewById(R.id.division);
        btres=(Button)findViewById(R.id.igual);
        btdot=(Button)findViewById(R.id.dot);
        btclean=(Button)findViewById(R.id.clear);
        blank=(TextView) findViewById(R.id.ggg);

        bt1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v)
            {
                blank.setText(blank.getText()+"1");
            }
        });
        bt2.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v)
            {
                blank.setText(blank.getText()+"2");
            }
        });
        bt3.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v)
            {
                blank.setText(blank.getText()+"3");
            }
        });
        bt4.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v)
            {
                blank.setText(blank.getText()+"4");
            }
        });
        bt5.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v)
            {
                blank.setText(blank.getText()+"5");
            }
        });
        bt6.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v)
            {
                blank.setText(blank.getText()+"6");
            }
        });
        bt7.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v)
            {
                blank.setText(blank.getText()+"7");
            }
        });
        bt8.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v)
            {
                blank.setText(blank.getText()+"8");
            }
        });
        bt9.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v)
            {
                blank.setText(blank.getText()+"9");
            }
        });
        bt0.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v)
            {
                blank.setText(blank.getText()+"0");
            }
        });
        btdot.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v)
            {
                blank.setText(blank.getText()+".");
            }
        });
        btclean.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v)
            {
                blank.setText("");
                numb1 = 0f;
                numb2 = 0f;
            }
        });
        btadd.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v)
            {
                if (blank.getText().toString().length()<1){
                    blank.setText("");
                }else {
                    try{
                        numb1 = Float.parseFloat(blank.getText().toString());
                        add= true;
                        blank.setText(null);

                    }
                    catch (Exception e)
                    {
                        blank.setText(e.toString());

                    }


                }
            }
        });
        btsub.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (blank.getText().toString().length()<1){
                    blank.setText("");
                }else {
                    numb1 = Float.parseFloat(blank.getText() + "");
                    sub = true;
                    blank.setText(null);
                }
            }
        });
        btmul.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (blank.getText().toString().length() < 1) {
                    blank.setText("");
                } else {
                    numb1 = Float.parseFloat(blank.getText() + "");
                    mul = true;
                    blank.setText(null);
                }
            }

        });
        btdiv.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (blank.getText().toString().length() < 1) {
                    blank.setText("");
                } else {
                    numb1 = Float.parseFloat(blank.getText() + "");
                    div = true;
                    blank.setText(null);
                }
            }
        });
        btres.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {

                if (blank.getText().toString().length() < 1)
                {
                    blank.setText("");
                }
                else {
                    try {
                        numb2 = Float.parseFloat(blank.getText().toString());
                        if (add) {

                            blank.setText(numb1 + numb2 + "");
                            add = false;
                        }


                        if (sub) {
                            blank.setText(numb1 - numb2 + "");
                            sub = false;
                        }

                        if (mul) {
                            blank.setText(numb1 * numb2 + "");
                            mul = false;
                        }

                        if (div) {
                            blank.setText(numb1 / numb2 + "");
                            div = false;
                        }
                    } catch (Exception e) {
                        blank.setText(e.toString());
                    }

                }
            }
        });
    }
}


