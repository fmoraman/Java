package com.example.fmora.secondpp;

public class Data {
    private int id;
    private String name,grade,city;
    private int yes;
    private int no;

    public Data(){}

    public Data(int id, String name, String materia, int yes, int no, String city){
        this.id = id;
        this.name = name;
        this.grade = materia;
        this.yes = yes;
        this.no = no;
        this.city=city;
    }

    public int getId(){return this.id;}
    public void setId(int id){this.id = id;}
    public String getName(){return this.name;}
    public void setName(String name){this.name = name;}
    public String getGrade(){return this.grade;}
    public void setGrade(String grade){this.grade = grade;}
    public int getYes(){return this.yes;}
    public void setYes(int yes){this.yes = yes;}
    public int getNo(){return this.no;}
    public void setNo(int no){this.no = no;}
    public String getCity() { return this.city;}
    public void setCity(String city) {this.city = city;}
}

