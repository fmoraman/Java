package com.example.fmora.secondpp;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class ControlDB extends SQLiteOpenHelper {
    SQLiteDatabase db;
    private String tabla = "tblMaestro";
    private String tblMaestro = "CREATE TABLE " + tabla +
            " (Registro INTEGER, Nombre TEXT, Materia TEXT, Asistencias INTEGER, Faltas INTEGER, Ciudad TEXT )";


    public ControlDB(Context contexto, String nombre, SQLiteDatabase.CursorFactory factory, int version)
    {
        super(contexto, nombre, factory, version);
    }

    public void onCreate(SQLiteDatabase db)
    {
        db.execSQL(tblMaestro);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int versionAnterior, int versionNueva)
    {
        db.execSQL("DROP TABLE IF EXISTS tblClientes");
        db.execSQL(tblMaestro);
    }

    public SQLiteDatabase conectar()
    {
        db = this.getWritableDatabase();
        return db;
    }

    public void cerrar()
    {
        if(db != null)
        {
            db.close();
        }
    }

    public boolean verificarMaestroID(int posibleid){
        this.conectar();
        boolean resultado = false;
        String[] args = new String[]{Integer.toString(posibleid)};
        Cursor c = db.rawQuery("SELECT * FROM " + tabla + " WHERE Registro = ?", args);
        if(c.moveToFirst()){
            resultado = false;
        }
        else{
            resultado = true;
        }
        this.cerrar();
        return resultado;
    }

    public void agregarMaestro(int id, String nombre, String materia, String ciudad)
    {
        this.conectar();
        db.execSQL("INSERT INTO " + tabla + " (Registro, Nombre, Materia, Asistencias, Faltas, Ciudad)" +
                " VALUES (" + id + ", '" + nombre +"', '" + materia +"', 0 , 0, '" + ciudad +"')");
        this.cerrar();
    }

    public Data consultarMaestro(int registro){
        this.conectar();
        String[] args = new String[]{Integer.toString(registro)};
        Cursor c = db.rawQuery(" SELECT * FROM " + tabla + " WHERE Registro = ?", args);
        Data maestro;
        if (c.moveToFirst()) {
            maestro = new Data();
            maestro.setId(c.getInt(0));
            maestro.setName(c.getString(1));
            maestro.setGrade(c.getString(2));
            maestro.setYes(c.getInt(3));
            maestro.setNo(c.getInt(4));
            maestro.setCity(c.getString(5));
        }
        else
            maestro = null;
        this.cerrar();
        return maestro;
    }

    public boolean agregarAsistencia(int registro, int asistencias){
        try{
            this.conectar();
            String[] args = new String[]{Integer.toString(asistencias+1), Integer.toString(registro)};
            db.execSQL("UPDATE " + tabla + " SET Asistencias = ? WHERE Registro = ?", args);
            this.cerrar();
            return true;
        }
        catch(Exception e) {
            return false;
        }
    }

    public boolean agregarFalta(int registro, int faltas){
        try{
            this.conectar();
            String[] args = new String[]{Integer.toString(faltas+1), Integer.toString(registro)};
            db.execSQL("UPDATE " + tabla + " SET Faltas = ? WHERE Registro = ?", args);
            this.cerrar();
            return true;
        }
        catch(Exception e) {
            return false;
        }
    }

        /*
        public boolean eliminarCliente(int eliminarid){
            try{
                this.conectar();
                String[] args = new String[]{Integer.toString(eliminarid)};
                db.execSQL("DELETE FROM tblClientes WHERE ID = ?", args);
                this.cerrar();
                return true;
            }
            catch(Exception e) {
                return false;
            }
        }
        */

    public int obtenerRegistros()
    {
        this.conectar();
        int registros = 0;
        Cursor c = db.rawQuery(" SELECT COUNT(*) FROM "+ tabla +" ", null);
        if (c.moveToFirst()) {
            registros = c.getInt(0);
        }
        this.cerrar();
        return registros;
    }
}


