package com.example.fmora.secondpp;

import android.content.Context;
import android.content.Intent;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.TextView;

import java.io.IOException;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    private ControlDB controlDB;
    private TextView name;
    private TextView signature;
    private TextView asistence;
    private TextView miss;
    private TextView label_default;
    private TextView label_detail;
    private TextView city, latalt;
    private EditText id;
   //private Button BtnAgregar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        controlDB = new ControlDB(getApplicationContext(),"DBMaestros",null,1);

        id = (EditText) findViewById(R.id.TxtRegistro);
        name = (TextView) findViewById(R.id.TxtNombre);
        signature = (TextView) findViewById(R.id.TxtMateria);
        asistence = (TextView) findViewById(R.id.TxtAsistencia);
        miss = (TextView) findViewById(R.id.TxtFaltas);
        city=(TextView)findViewById(R.id.ciudad);
        latalt=(TextView)findViewById(R.id.coordenadas);

        label_default = (TextView)findViewById(R.id.LblDefault);
        label_detail = (TextView)findViewById(R.id.LblDetalle);

        mostrarRegistros();
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.opciones_main, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        Intent intent = null;
        boolean status = false;
        switch (item.getItemId()) {
            case R.id.OpcBuscar:
                if(controlDB.obtenerRegistros() == 0){
                    label_detail.setText("Aun no se han registrado clientes");
                }
                else{
                    status = true;
                    int posibleid = 0;
                    try{
                        posibleid = Integer.parseInt(id.getEditableText().toString());
                    }
                    catch (Exception e){
                        status = false;
                    }
                    if(!status){
                        label_detail.setText("Por favor, introduzca un registro valido");
                    }
                    else{
                        Data posibleMaestro = controlDB.consultarMaestro(posibleid);
                        if(posibleMaestro == null)
                        {
                            label_detail.setText("No se ha encontrado el maestro con el registro '" + posibleid + "'. Por favor, intentelo de nuevo");
                        }
                        else{
                            id.setText(Integer.toString(posibleMaestro.getId()));
                            name.setText(posibleMaestro.getName());
                            signature.setText(posibleMaestro.getGrade());
                            asistence.setText(Integer.toString(posibleMaestro.getYes()));
                            miss.setText(Integer.toString(posibleMaestro.getNo()));
                            city.setText(posibleMaestro.getCity());


                        if(city.equals("Zapopan")){
                            List<Address> listOfAddress;
                            Geocoder geocoder = new Geocoder(this);

                            try {
                                listOfAddress = geocoder.getFromLocationName("Zapopan", 1);
                                Address location= listOfAddress.get(0);
                                double latitude = location.getLatitude();
                                double longitud = location.getLongitude();
                                String finito=Double.toString(latitude);
                                String finito2=Double.toString(longitud);
                                latalt.setText(finito+finito2);

                            } catch (IOException e) {
                                e.printStackTrace();
                            }

                            }
                            if(city.equals("San Cristobal")){
                                List<Address> listOfAddress;
                                Geocoder geocoder = new Geocoder(this);

                                try {
                                    listOfAddress = geocoder.getFromLocationName("San Cristobal", 1);
                                    Address location= listOfAddress.get(0);
                                    double latitude = location.getLatitude();
                                    double longitud = location.getLongitude();
                                    String finito=Double.toString(latitude);
                                    String finito2=Double.toString(longitud);
                                    latalt.setText(finito+finito2);

                                } catch (IOException e) {
                                    e.printStackTrace();
                                }

                            }
                            if(city.equals("Monterrey")){
                                List<Address> listOfAddress;
                                Geocoder geocoder = new Geocoder(this);

                                try {
                                    listOfAddress = geocoder.getFromLocationName("Monterrey", 1);
                                    Address location= listOfAddress.get(0);
                                    double latitude = location.getLatitude();
                                    double longitud = location.getLongitude();
                                    String finito=Double.toString(latitude);
                                    String finito2=Double.toString(longitud);
                                    latalt.setText(finito+finito2);

                                } catch (IOException e) {
                                    e.printStackTrace();
                                }

                            }
                            if(city.equals("Ciudad de Mexico")){
                                List<Address> listOfAddress;
                                Geocoder geocoder = new Geocoder(this);

                                try {
                                    listOfAddress = geocoder.getFromLocationName("Ciudad de Mexico", 1);
                                    Address location= listOfAddress.get(0);
                                    double latitude = location.getLatitude();
                                    double longitud = location.getLongitude();
                                    String finito=Double.toString(latitude);
                                    String finito2=Double.toString(longitud);
                                    latalt.setText(finito+finito2);

                                } catch (IOException e) {
                                    e.printStackTrace();
                                }

                            }
                            if(city.equals("Villahermosa")){
                                List<Address> listOfAddress;
                                Geocoder geocoder = new Geocoder(this);

                                try {
                                    listOfAddress = geocoder.getFromLocationName("Villahermosa", 1);
                                    Address location= listOfAddress.get(0);
                                    double latitude = location.getLatitude();
                                    double longitud = location.getLongitude();
                                    String finito=Double.toString(latitude);
                                    String finito2=Double.toString(longitud);
                                    latalt.setText(finito+finito2);

                                } catch (IOException e) {
                                    e.printStackTrace();
                                }

                            }
                            //api key: AIzaSyDZMmL8v3yD9Sz-wiqykZaFLFNpqFSaHaE
                        }
                    }
                }
                return true;

            case R.id.OpcAsistencia:
                status = true;
                int asistenciaid = 0;
                try{
                    try{
                        asistenciaid = Integer.parseInt(id.getEditableText().toString());
                    }
                    catch (Exception e){
                        label_detail.setText("Por favor, introduzca un registro valido");
                        return true;
                    }
                    status = controlDB.verificarMaestroID(asistenciaid);
                    if(!status){
                        int asistencias = Integer.parseInt(asistence.getText().toString());
                        boolean verificarasistencia = controlDB.agregarAsistencia(asistenciaid, asistencias );
                        if(verificarasistencia){
                            label_detail.setText("Se ha agregado la asistencia al registro '" + asistenciaid + "' de manera correcta");
                            Data posibleMaestro = controlDB.consultarMaestro(asistenciaid);
                            asistence.setText(Integer.toString(posibleMaestro.getYes()));
                            return true;
                        }
                    }
                    else{
                        label_detail.setText("El maestro con el registro '" + asistenciaid + "' no ha sido encontrado. Verifique que el ID sea correcto");
                    }
                }
                catch(Exception e){
                    label_detail.setText("Primero verifique que el registro a modificar sea correcto, para ello utilice la opcion 'Buscar'");
                }
                return true;

            case R.id.OpcFalta:
                status = true;
                int faltaid = 0;
                try{
                    try{
                        faltaid = Integer.parseInt(id.getEditableText().toString());
                    }
                    catch (Exception e){
                        label_detail.setText("Por favor, introduzca un registro valido");
                        return true;
                    }
                    status = controlDB.verificarMaestroID(faltaid);
                    if(!status){
                        int faltas = Integer.parseInt(miss.getText().toString());
                        boolean verificarasistencia = controlDB.agregarFalta(faltaid, faltas );
                        if(verificarasistencia){
                            label_detail.setText("Se ha agregado la asistencia al registro '" + faltaid + "' de manera correcta");
                            Data posibleMaestro = controlDB.consultarMaestro(faltaid);
                            miss.setText(Integer.toString(posibleMaestro.getNo()));
                            return true;
                        }
                    }
                    else{
                        label_detail.setText("El mestro con el registro '" + faltaid + "' no ha sido encontrado. Verifique que el ID sea correcto");
                    }
                }
                catch(Exception e){
                    label_detail.setText("Primero verifique que el registro a modificar sea correcto, para ello utilice la opcion 'Buscar'");
                }
                return true;
            case R.id.nuevo:
                Intent i = new Intent(MainActivity.this, Add.class);
                startActivityForResult(i, 0);
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }

    public void mostrarRegistros(){
        label_default.setText("Maestros registrados: " + controlDB.obtenerRegistros());
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        mostrarRegistros();
    }

}


