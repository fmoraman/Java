package com.example.fmora.secondpp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

public class Add extends AppCompatActivity {
    private Spinner grades,Sede;
    private ControlDB controlDB;
    private Button add;

    private EditText id, name;
    private TextView label_def, label_det;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);
        controlDB = new ControlDB(getApplicationContext(),"DBMaestros",null,1);

        id = (EditText) findViewById(R.id.TxtRegistro);
        name = (EditText) findViewById(R.id.TxtNombre);

        label_def = (TextView)findViewById(R.id.LblDefault);
        label_det = (TextView)findViewById(R.id.LblDetalle);

        grades = (Spinner)findViewById(R.id.CmbMaterias);
        Sede=(Spinner)findViewById(R.id.Ciudades);
        final String[] ciudades =
                new String[]{"Zapopan","Villahermosa","San Cristobal","Monterrey","Ciudad de Mexico"};
        ArrayAdapter<String> adaptador2 =
                new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item, ciudades);
        adaptador2.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item);
        Sede.setAdapter(adaptador2);
        Sede.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        final String[] datos =
                new String[]{"Matematicas","Programacion Avanzada","Ingenieria de Software","Android","Circuitos"};
        ArrayAdapter<String> adaptador =
                new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item, datos);
        adaptador.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item);
        grades.setAdapter(adaptador);

        grades.setOnItemSelectedListener(
                new AdapterView.OnItemSelectedListener() {
                    public void onItemSelected(AdapterView<?> parent,
                                               android.view.View v, int position, long id) {

                    }

                    public void onNothingSelected(AdapterView<?> parent) {

                    }
                });

        add = (Button)findViewById(R.id.BtnAgregar);
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean status = true;
                int posibleid = 0;
                try{
                    posibleid = Integer.parseInt(id.getEditableText().toString());
                }
                catch (Exception e){
                    status = false;
                }
                if(status){
                    boolean verificarid = controlDB.verificarMaestroID(posibleid);
                    if(!verificarid){
                        label_det.setText("El registro " + posibleid + " esta en uso. Por favor, intente con uno diferente");
                    }
                    else{
                        String nombre = name.getEditableText().toString();
                        String materia = grades.getSelectedItem().toString();
                        String city=Sede.getSelectedItem().toString();
                        try{
                            controlDB.agregarMaestro( posibleid,nombre, materia,city);
                            id.setText("");
                            name.setText("");
                            label_det.setText("Se ha agregado el maestro de manera exitosa");
                        }
                        catch (Exception e){
                            label_det.setText("Error al agregar al maestro, intentelo de nuevo");
                        }
                    }
                }
                else{
                    label_det.setText("Por favor, introduzca un registro valido");
                }

            }
        });
    }


}


