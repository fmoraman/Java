package com.example.fmora.forfox;

public class datacar {
    private int idd;
    private String name, model, brand;

    public  datacar(int idd, String name, String model, String brand){
        super();
        this.idd=idd;
        this.name=name;
        this.model=model;
        this.brand=brand;
    }
    public datacar(){}

    public int getIdd() {
        return idd;
    }

    public void setIdd(int idd) {
        this.idd = idd;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }
}
