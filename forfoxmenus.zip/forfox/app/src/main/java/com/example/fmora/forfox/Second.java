package com.example.fmora.forfox;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class Second extends AppCompatActivity {
    private TextView idD, nameD, modelD, brandD, numciD, priceD;
    private ImageView gg;

    @Override
    @SuppressLint("SetTextI18n")
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        idD=(TextView)findViewById(R.id.idD);
        nameD=(TextView)findViewById(R.id.nombreD);
        modelD=(TextView)findViewById(R.id.modeloD);
        brandD=(TextView)findViewById(R.id.marcaD);
        numciD=(TextView)findViewById(R.id.numciD);
        priceD=(TextView)findViewById(R.id.precioD);
        gg=(ImageView)findViewById(R.id.gg);

        Bundle datos=getIntent().getExtras();

        idD.setText(datos.getString("id"));
        nameD.setText(datos.getString("name"));
        modelD.setText(datos.getString("model"));
        brandD.setText(datos.getString("brand"));
        numciD.setText(datos.getString("numc"));
        priceD.setText(datos.getString("price"));

        if(brandD.getText().toString().equals("Corvette")){
            gg.setImageResource(R.drawable.zr1);
        }
        if(brandD.getText().toString().equals("Audi")){
            gg.setImageResource(R.drawable.r8plis);
        }
        if(brandD.getText().toString().equals("Mini Cooper")){
            gg.setImageResource(R.drawable.mini);
        }


    }
}
