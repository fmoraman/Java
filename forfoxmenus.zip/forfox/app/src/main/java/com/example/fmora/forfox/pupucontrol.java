package com.example.fmora.forfox;

public class pupucontrol {
    private datacar datos[];
    private int DataAcc;

    public pupucontrol(){
        datos= new datacar[10];
        DataAcc=0;
    }

    public static void remove(int position) {

    }

    public void setDatacar(datacar k){
        if(DataAcc<10)
        {
            datos[DataAcc] = k;
            DataAcc++;
        }
    }
    public datacar consultar (datacar k){
        datacar obj = new datacar();
        for(int x = 0; x < DataAcc; x++){
            if(datos[x].getIdd()==k.getIdd()){
                obj=datos[x];
                break;
            }
        }
        return obj;
    }
}


