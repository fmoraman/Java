package com.example.fmora.forfox;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.ResourceBundle;

public class MainActivity extends AppCompatActivity {
    private TextView Id, name, model, brand;
    private Button details;
    private Spinner spinner;
    private String carr;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Id=(TextView) findViewById(R.id.id);
        name=(TextView) findViewById(R.id.nombre);
        model=(TextView) findViewById(R.id.modelo);
        brand=(TextView) findViewById(R.id.marca);
        details=(Button)findViewById(R.id.detalles);
        spinner=(Spinner)findViewById(R.id.spinner);

        final String[] car=new String[]{"Seleccione", "Corvette", "Audi","Mini Cooper"};
        ArrayAdapter<String> adaptador= new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, car);
        spinner.setAdapter(adaptador);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            @SuppressLint("SetTextI18n")
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                carr=car[position];
                if(carr == "Corvette"){
                    Id.setText("755");
                    name.setText("ZR1");
                    model.setText("2019");
                    brand.setText("Corvette");
                }
                if(carr == "Audi"){
                    Id.setText("540");
                    name.setText("R8 Spyder");
                    model.setText("2019");
                    brand.setText("Audi");
                }
                if(carr == "Mini Cooper"){
                    Id.setText("235");
                    name.setText("Mini Cooper S 3 door");
                    model.setText("2019");
                    brand.setText("Mini Cooper");
                }
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
        details.setOnClickListener(new View.OnClickListener() {
            @Override
            @SuppressLint("SetTextI18n")
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Second.class);
                if(carr == "Corvette"){
                    intent.putExtra("id","755");
                    intent.putExtra("name","ZR1");
                    intent.putExtra("model","2019");
                    intent.putExtra("brand","Corvette");
                    intent.putExtra("numc","8 en V");
                    intent.putExtra("price","$2,784,900");
                }
                if(carr == "Audi"){
                    intent.putExtra("id","540");
                    intent.putExtra("name","R8 Spyder");
                    intent.putExtra("model","2019");
                    intent.putExtra("brand","Audi");
                    intent.putExtra("numc","10 en V");
                    intent.putExtra("price","$3,179,900");
                }
                if(carr == "Mini Cooper"){
                    intent.putExtra("id","235");
                    intent.putExtra("name","Mini Cooper S 3 door");
                    intent.putExtra("model","2019");
                    intent.putExtra("brand","Mini Cooper");
                    intent.putExtra("numc","4");
                    intent.putExtra("price","$554,900");
                }
                startActivity(intent);
            }
        });
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        switch(item.getItemId()){
            case R.id.add:
                Intent i = new Intent(MainActivity.this, fivivi.class);
                startActivity(i);
                return true;
            case R.id.modify:
                Intent j = new Intent(MainActivity.this, fivivi.class);
                j.putExtra("id","755");
                j.putExtra("name","ZR1");
                j.putExtra("model","2019");
                j.putExtra("brand","Corvette");

                j.putExtra("idd","540");
                j.putExtra("namee","R8 Spyder");
                j.putExtra("modell","2019");
                j.putExtra("brandd","Audi");

                j.putExtra("iddd","235");
                j.putExtra("nameee","Mini Cooper S 3 door");
                j.putExtra("modelll","2019");
                j.putExtra("branddd","Mini Cooper");
                startActivity(j);
                return true;
            case R.id.cons:
                Intent k = new Intent(MainActivity.this, fivivi.class);

                    k.putExtra("id","755");
                    k.putExtra("name","ZR1");
                    k.putExtra("model","2019");
                    k.putExtra("brand","Corvette");

                    k.putExtra("idd","540");
                    k.putExtra("namee","R8 Spyder");
                    k.putExtra("modell","2019");
                    k.putExtra("brandd","Audi");

                    k.putExtra("iddd","235");
                    k.putExtra("nameee","Mini Cooper S 3 door");
                    k.putExtra("modelll","2019");
                    k.putExtra("branddd","Mini Cooper");


                startActivity(k);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
