package com.example.fmora.forfox;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.view.ContextMenu;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.AdapterView;
import android.widget.AdapterView.AdapterContextMenuInfo;



public class fivivi extends AppCompatActivity {
    private EditText Id, model, name, brand;
    private Button add, cons, modify;
    private pupucontrol control;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fivivi);
        control = new pupucontrol();

        Id = (EditText) findViewById(R.id.id);
        name = (EditText) findViewById(R.id.nombre);
        brand = (EditText) findViewById(R.id.marca);
        model = (EditText) findViewById(R.id.modelo);



        add = (Button) findViewById(R.id.add);
        cons = (Button) findViewById(R.id.cons);
        modify = (Button) findViewById(R.id.modify);
        this.registerForContextMenu(modify);


        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int kk = Integer.parseInt(Id.getEditableText().toString());
                String Name = name.getEditableText().toString();
                String Model = model.getEditableText().toString();
                String Brand = brand.getEditableText().toString();

                datacar k = new datacar(kk, Name, Model, Brand);
                control.setDatacar(k);
                Id.setText("");
                name.setText("");
                model.setText("");
                brand.setText("");
            }
        });

        cons.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int id=Integer.parseInt(Id.getEditableText().toString());
                datacar k = new datacar();
                k.setIdd(id);
                final datacar data =control.consultar(k);
                if(data.getIdd()>0){
                    name.setText(data.getName());
                    model.setText(data.getModel());
                    brand.setText(data.getBrand());
                }
                Bundle popis =getIntent().getExtras();
                if(Id.getEditableText().toString().equals("755")){
                    name.setText(popis.getString("name"));
                    model.setText(popis.getString("model"));
                    brand.setText(popis.getString("brand"));
                }
                if(Id.getEditableText().toString().equals("540")){
                    name.setText(popis.getString("namee"));
                    model.setText(popis.getString("modell"));
                    brand.setText(popis.getString("brandd"));
                }
                if(Id.getEditableText().toString().equals("235")){
                    name.setText(popis.getString("nameee"));
                    model.setText(popis.getString("modelll"));
                    brand.setText(popis.getString("branddd"));
                }
            }
        });
        modify.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int id=Integer.parseInt(Id.getEditableText().toString());
                datacar k = new datacar();
                k.setIdd(id);
                final datacar data =control.consultar(k);
                if(data.getIdd()>0){
                    name.setText(data.getName());
                    model.setText(data.getModel());
                    brand.setText(data.getBrand());
                }
                Bundle popis =getIntent().getExtras();
                if(Id.getEditableText().toString().equals("755")){
                    name.setText(popis.getString("name"));
                    model.setText(popis.getString("model"));
                    brand.setText(popis.getString("brand"));
                }
                if(Id.getEditableText().toString().equals("540")){
                    name.setText(popis.getString("namee"));
                    model.setText(popis.getString("modell"));
                    brand.setText(popis.getString("brandd"));
                }
                if(Id.getEditableText().toString().equals("235")){
                    name.setText(popis.getString("nameee"));
                    model.setText(popis.getString("modelll"));
                    brand.setText(popis.getString("branddd"));
                }
                int kk = Integer.parseInt(Id.getEditableText().toString());
                String Name = name.getEditableText().toString();
                String Model = model.getEditableText().toString();
                String Brand = brand.getEditableText().toString();

                datacar p = new datacar(kk, Name, Model, Brand);
                control.setDatacar(p);
                Id.setText("");
                name.setText("");
                model.setText("");
                brand.setText("");

            }
        });

    }
    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenuInfo menuInfo){
        super.onCreateContextMenu(menu, v, menuInfo);

        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.contextual, menu);
    }
    public boolean onContextItemSelected(MenuItem item){
        AdapterContextMenuInfo carrorun=(AdapterContextMenuInfo) item.getMenuInfo();
        switch(item.getItemId()){
            case R.id.delete:
                eliminarauto(carrorun);
                return true;
            default:
                return super.onOptionsItemSelected(item);

        }
    }

    private void eliminarauto(AdapterContextMenuInfo info){
        pupucontrol.remove(info.position);
        Id.setText("");
        name.setText("");
        model.setText("");
        brand.setText("");
    }

}

